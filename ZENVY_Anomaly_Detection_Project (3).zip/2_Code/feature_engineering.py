
def create_features(df):
    df['salary_change_pct'] = df.groupby('emp_id')['salary'].pct_change().fillna(0)
    df['ot_per_day'] = df['overtime_hours'] / (df['working_days'] + 1)
    return df
