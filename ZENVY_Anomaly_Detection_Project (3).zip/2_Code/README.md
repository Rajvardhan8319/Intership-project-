
ZENVY Payroll Anomaly Detection

Objective:
Detect salary manipulation and fake overtime using unsupervised learning.

Model:
Isolation Forest

Run:
1. Train using train_model.py
2. Predict using inference.py
