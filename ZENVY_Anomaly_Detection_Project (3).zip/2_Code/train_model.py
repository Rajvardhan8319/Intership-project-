
from sklearn.ensemble import IsolationForest
import joblib

def train(X):
    model = IsolationForest(n_estimators=200, contamination=0.02, random_state=42)
    model.fit(X)
    joblib.dump(model, "model.pkl")
