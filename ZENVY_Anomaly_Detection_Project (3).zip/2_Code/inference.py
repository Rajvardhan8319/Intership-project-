
import joblib

model = joblib.load("model.pkl")

def predict(X):
    return model.decision_function(X)
